﻿#include <iostream>
#include <vector>
#include <iomanip>
#include <limits>

using namespace std;


void printTableau(const vector<vector<double>>& tableau) {
    for (const auto& row : tableau) {
        for (double val : row) {
            cout << setw(10) << val << " ";
        }
        cout << endl;
    }
    cout << "-------------------------" << endl;
}


void simplex(vector<vector<double>>& tableau) {
    int rows = tableau.size();
    int cols = tableau[0].size();

    while (true) {
        
        int pivotCol = -1;
        for (int j = 0; j < cols - 1; ++j) {
            if (tableau[rows - 1][j] < 0) {
                pivotCol = j;
                break;
            }
        }
        if (pivotCol == -1) break;  
       
        int pivotRow = -1;
        double minRatio = numeric_limits<double>::max();
        for (int i = 0; i < rows - 1; ++i) {
            if (tableau[i][pivotCol] > 0) {
                double ratio = tableau[i][cols - 1] / tableau[i][pivotCol];
                if (ratio < minRatio) {
                    minRatio = ratio;
                    pivotRow = i;
                }
            }
        }
        if (pivotRow == -1) {
            cout << "Задача неограничена." << endl;
            return;
        }

        
        double pivotValue = tableau[pivotRow][pivotCol];
        for (int j = 0; j < cols; ++j) {
            tableau[pivotRow][j] /= pivotValue;
        }

    
        for (int i = 0; i < rows; ++i) {
            if (i != pivotRow) {
                double factor = tableau[i][pivotCol];
                for (int j = 0; j < cols; ++j) {
                    tableau[i][j] -= factor * tableau[pivotRow][j];
                }
            }
        }

       
        printTableau(tableau);
    }
}

int main() {
    
    vector<vector<double>> tableau = {
        {1, 1, 1, 0, 0, 6},    
        {1, -2, 0, 1, 0, 4},   
        {1, -3, 0, 0, 1, 3},   
        {-3, -2, 0, 0, 0, 0}   
    };

    cout << "Initial Tableau:" << endl;
    printTableau(tableau);

   
    simplex(tableau);

   
    cout << "Final Tableau:" << endl;
    printTableau(tableau);

    // Оптимальное значение целевой функции
    int rows = tableau.size();
    int cols = tableau[0].size();
    cout << "Optimal value: " << tableau[rows - 1][cols - 1] << endl;


    cout << "Press Enter to exit...";
    cin.get();

    return 0;

   
}